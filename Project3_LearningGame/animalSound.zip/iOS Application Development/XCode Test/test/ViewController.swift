//
//  ViewController.swift
//  test
//
//  Created by Andy Duong on 23/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

 var audioPlayer = AVAudioPlayer()
    @IBOutlet weak var mooButton: UIButton!
    
    @IBAction func moo(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Moo", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    @IBOutlet weak var neighButton: UIButton!
    
    @IBAction func neigh(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Neigh", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    @IBOutlet weak var quackButton: UIButton!
    
    @IBAction func quack(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Quack", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    @IBOutlet weak var woofButton: UIButton!
    
    @IBAction func woof(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Bark", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    @IBOutlet weak var snortButton: UIButton!
    
    @IBAction func snort(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Pig Snort", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    @IBOutlet weak var bleatButton: UIButton!
    
    @IBAction func bleat(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Bleat", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    
    @IBOutlet weak var croakButton: UIButton!
    
    @IBAction func croak(_ sender: Any) {
        do
        {
            let audioPath = Bundle.main.path(forResource: "Croak", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
        }
        catch
        {
            // ERROR
        }
        
        audioPlayer.play()
    }
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

