//
//  missingLetterA.swift
//  week10
//
//  Created by Andy Duong on 24/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit

class missingLetterA: UIViewController {

    @IBOutlet weak var missingLabel: UILabel!
    @IBOutlet weak var missingLabel2: UILabel!
    @IBOutlet weak var buttonD: UIButton!
    @IBOutlet weak var buttonE: UIButton!
    @IBOutlet weak var buttonF: UIButton!
    @IBOutlet weak var buttonG: UIButton!
    @IBOutlet weak var buttonNext: UIButton!
    
    
    
    @IBAction func buttonNextTapped(_ sender: Any) {
        performSegue(withIdentifier: "MissingLetterSegue", sender: self)
    }
    
    @IBAction func buttonDTapped(_ sender: Any) {
        missingLabel.text = "D"
        next()
    }
    @IBAction func buttonETapped(_ sender: Any) {
        missingLabel2.text = "E"
        next()
        
    }
    @IBAction func buttonFTapped(_ sender: Any) {
        buttonF.isHidden = true
    }
    
    @IBAction func buttonGTapped(_ sender: Any) {
        buttonG.isHidden = true
    }
    
    func next(){
        if( missingLabel.text == "D" && missingLabel2.text == "E"){
        buttonNext.isHidden = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonNext.isHidden = true
        


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
