//
//  playSound2.swift
//  week10
//
//  Created by Andy Duong on 24/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit

class playSound2: UIViewController {

    @IBAction func segue2(_ sender: Any) {
        performSegue(withIdentifier: "placeholder", sender: self)
    }
}
