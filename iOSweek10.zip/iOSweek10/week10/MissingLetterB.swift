//
//  MissingLetterB.swift
//  week10
//
//  Created by Andy Duong on 24/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit

class MissingLetterB: UIViewController {

    @IBOutlet weak var buttonNext: UIButton!
    @IBOutlet weak var missingLabel: UILabel!
    @IBOutlet weak var buttonH: UIButton!
    @IBOutlet weak var buttonI: UIButton!
    @IBOutlet weak var buttonJ: UIButton!
    @IBOutlet weak var buttonK: UIButton!
    
    
    
    @IBAction func buttonHTapped(_ sender: Any) {
        buttonH.isHidden = true
    }
    @IBAction func buttonITapped(_ sender: Any) {
        missingLabel.text = "I"
        next()
    }
    @IBAction func buttonJTapped(_ sender: Any) {
        buttonJ.isHidden = true
    }
    @IBAction func buttonKTapped(_ sender: Any) {
        buttonK.isHidden = true
    }
    
    func next(){
        if (missingLabel.text == "I"){
            buttonNext.isHidden = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonNext.isHidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
