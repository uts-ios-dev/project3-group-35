//
//  playSound.swift
//  week10
//
//  Created by Andy Duong on 24/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit

class playSound: UIViewController {
    @IBAction func moo(_ sender: Any) {
        
    }

    
    
    
    @IBOutlet var imageTapped: UITapGestureRecognizer!
    
    @IBAction func tapped(_ sender: Any) {
        performSegue(withIdentifier: "segue", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
