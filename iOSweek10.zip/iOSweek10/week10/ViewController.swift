//
//  ViewController.swift
//  week10
//
//  Created by Andy Duong on 24/5/18.
//  Copyright © 2018 Andy Duong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        func unwind(unwindSegue: UIStoryboardSegue){
        
        }
    
    @IBAction func unwindToHome(unwindSegue: UIStoryboardSegue) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

